# Multiplicación Matricial Paralela

Para ejecutar correctamente el script ejecute en la raíz del proyecto el comando
```sh
bash script.sh
```

Es necesario tener configurado OMP, CUDA y MPI para ejecutar todo el script, se puede ejecutar cada implementación con su propio script.
```sh
cd omp/
bash script.sh
```
```sh
cd mpi/
bash script.sh
```
```sh
cd cuda/
bash script.sh
```